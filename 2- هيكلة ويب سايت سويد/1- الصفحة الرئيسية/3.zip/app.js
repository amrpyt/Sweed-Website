// Enhanced DOM Elements
const heroSlides = document.querySelectorAll('.slide');
const prevSlideBtn = document.querySelector('.prev-slide');
const nextSlideBtn = document.querySelector('.next-slide');
const heroDots = document.querySelectorAll('.hero-dot');
const testimonialCards = document.querySelectorAll('.testimonial-card');
const prevTestimonialBtn = document.querySelector('.prev-testimonial');
const nextTestimonialBtn = document.querySelector('.next-testimonial');
const faqItems = document.querySelectorAll('.faq-item');
const helpForm = document.querySelector('.help-form');
const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
const nav = document.querySelector('.nav');

// New Enhanced Elements
const searchBtn = document.getElementById('searchBtn');
const searchModal = document.getElementById('searchModal');
const searchClose = document.querySelector('.search-close');
const searchInput = document.getElementById('searchInput');
const searchResults = document.getElementById('searchResults');

const downloadBtn = document.getElementById('downloadBtn');
const catalogModal = document.getElementById('catalogModal');
const catalogClose = document.querySelector('.catalog-close');
const directDownload = document.getElementById('directDownload');
const customCatalog = document.getElementById('customCatalog');
const catalogForm = document.getElementById('catalogForm');

const popupModal = document.getElementById('popupModal');
const popupClose = document.querySelector('.popup-close');
const popupForm = document.querySelector('.popup-form');

// Problems Section Elements
const problemsSlider = document.getElementById('problemsSlider');
const problemsPrev = document.querySelector('.problems-prev');
const problemsNext = document.querySelector('.problems-next');

// Portfolio Section Elements
const portfolioSlider = document.getElementById('portfolioSlider');
const portfolioPrev = document.querySelector('.portfolio-prev');
const portfolioNext = document.querySelector('.portfolio-next');

// Products Section Elements
const productsSlider = document.getElementById('productsSlider');
const productsPrev = document.querySelector('.products-prev');
const productsNext = document.querySelector('.products-next');

// Videos Section Elements
const videosPrev = document.querySelector('.videos-prev');
const videosNext = document.querySelector('.videos-next');
const videoItems = document.querySelectorAll('.video-item');

// Enhanced State Management
let currentSlide = 0;
let currentTestimonial = 0;
let currentProblemSet = 0;
let currentPortfolioSet = 0;
let currentProductSet = 0;
let currentVideoSet = 0;
let autoSlideInterval;
let popupTriggered = false;
let scrollPosition = 0;

// Configuration
const config = {
    heroAutoSlideDelay: 8000, // 8 seconds as requested
    testimonialAutoSlideDelay: 7000,
    popupScrollTrigger: 0.6, // 60% scroll
    popupTimeDelay: 30000, // 30 seconds
    problemsPerView: 2,
    portfolioPerView: 3,
    productsPerView: 3,
    videosPerView: 3
}

// Additional CSS for enhanced features
const additionalStyles = `
<style>
.video-modal {
    display: none;
    position: fixed;
    z-index: 2500;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(38, 27, 62, 0.9);
    backdrop-filter: blur(5px);
}

.video-modal.show {
    display: flex;
    align-items: center;
    justify-content: center;
    animation: fadeIn 0.3s ease;
}

.video-modal-content {
    background: var(--white);
    padding: 2rem;
    border-radius: var(--border-radius-lg);
    max-width: 600px;
    width: 90%;
    position: relative;
    text-align: center;
}

.video-close {
    position: absolute;
    top: 15px;
    right: 15px;
    font-size: 1.5rem;
    cursor: pointer;
    color: var(--dark-gray);
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: var(--transition);
}

.video-close:hover {
    background: var(--light-gray);
    color: var(--accent-color);
}

.video-placeholder-large {
    padding: 3rem 2rem;
    background: var(--light-gray);
    border-radius: var(--border-radius);
    color: var(--dark-gray);
}

.form-errors,
.success-message {
    position: fixed;
    top: 100px;
    right: 20px;
    z-index: 3000;
    padding: 1rem;
    border-radius: var(--border-radius);
    max-width: 400px;
    opacity: 0;
    transform: translateX(100%);
    transition: var(--transition);
}

.form-errors {
    background: #ffebee;
    border: 1px solid var(--accent-color);
    color: #c62828;
}

.success-message {
    background: #e8f5e8;
    border: 1px solid #4caf50;
    color: #2e7d32;
}

.success-message.show,
.form-errors.show {
    opacity: 1;
    transform: translateX(0);
}

.error-message,
.success-content {
    display: flex;
    align-items: flex-start;
    gap: 0.5rem;
}

.error-message ul {
    margin: 0;
    padding-left: 1rem;
}

.search-result-item {
    padding: 1rem;
    border-bottom: 1px solid var(--light-gray);
    cursor: pointer;
    transition: var(--transition);
}

.search-result-item:hover {
    background: var(--light-gray);
}

.search-result-item h4 {
    margin: 0 0 0.5rem 0;
    color: var(--primary-color);
}

.search-result-item p {
    margin: 0;
    color: var(--dark-gray);
    font-size: 0.9rem;
}

.no-results {
    text-align: center;
    padding: 2rem;
    color: var(--dark-gray);
}

.no-results i {
    font-size: 2rem;
    margin-bottom: 1rem;
    opacity: 0.5;
}

.package-card.selected {
    border-color: var(--accent-color);
    box-shadow: var(--shadow-hover);
    transform: scale(1.02);
}

.loading::after {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
    animation: loading-shimmer 1.5s infinite;
}

@keyframes loading-shimmer {
    0% { left: -100%; }
    100% { left: 100%; }
}

@keyframes pulse-urgent {
    0%, 100% {
        box-shadow: 0 0 0 0 rgba(237, 32, 98, 0.7);
        transform: scale(1);
    }
    50% {
        box-shadow: 0 0 0 10px rgba(237, 32, 98, 0);
        transform: scale(1.02);
    }
}

.countdown-timer.urgent {
    animation: pulse-urgent 2s infinite;
}

.input.error,
select.error {
    border-color: var(--accent-color) !important;
    box-shadow: 0 0 0 3px rgba(237, 32, 98, 0.1) !important;
}

.body.loaded {
    opacity: 1;
}

body.menu-open {
    overflow: hidden;
}

@media (max-width: 768px) {
    .nav.active {
        display: block;
        position: fixed;
        top: 80px;
        left: 0;
        right: 0;
        background: var(--white);
        box-shadow: var(--shadow);
        padding: 1rem;
        z-index: 999;
    }
    
    .nav.active .nav-list {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .form-errors,
    .success-message {
        right: 10px;
        left: 10px;
        max-width: none;
    }
}
</style>
`;

// Inject additional styles
document.head.insertAdjacentHTML('beforeend', additionalStyles);

// Initialize everything when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}

function initializeApp() {
    // All initialization is handled in the main DOMContentLoaded event
    console.log('🎯 App initialization complete!');
}

// Export functions for potential external use
window.SweidWebsite = {
    openModal,
    closeModal,
    showSuccessMessage,
    nextSlide,
    prevSlide,
    goToSlide
};

// END OF ENHANCED JAVASCRIPT

// Final initialization check
console.log('🎯 تم تحميل جميع المكونات بنجاح!');

// Problems Slider
function initializeProblemsSlider() {
    if (!problemsSlider || !problemsPrev || !problemsNext) return;
    
    const problems = problemsSlider.querySelectorAll('.problem-card');
    const totalProblems = problems.length;
    const problemsPerView = config.problemsPerView;
    const maxSets = Math.ceil(totalProblems / problemsPerView);
    
    function updateProblemsDisplay() {
        const startIndex = currentProblemSet * problemsPerView;
        const endIndex = Math.min(startIndex + problemsPerView, totalProblems);
        
        problems.forEach((problem, index) => {
            if (index >= startIndex && index < endIndex) {
                problem.style.display = 'block';
                problem.style.animation = 'fadeInUp 0.6s ease';
            } else {
                problem.style.display = 'none';
            }
        });
        
        // Update navigation buttons
        problemsPrev.style.opacity = currentProblemSet === 0 ? '0.5' : '1';
        problemsNext.style.opacity = currentProblemSet === maxSets - 1 ? '0.5' : '1';
    }
    
    problemsPrev.addEventListener('click', () => {
        if (currentProblemSet > 0) {
            currentProblemSet--;
            updateProblemsDisplay();
        }
    });
    
    problemsNext.addEventListener('click', () => {
        if (currentProblemSet < maxSets - 1) {
            currentProblemSet++;
            updateProblemsDisplay();
        }
    });
    
    // Initialize display
    updateProblemsDisplay();
    
    // Auto-advance every 5 seconds
    setInterval(() => {
        if (currentProblemSet < maxSets - 1) {
            currentProblemSet++;
        } else {
            currentProblemSet = 0;
        }
        updateProblemsDisplay();
    }, 5000);
}

// Portfolio Slider
function initializePortfolioSlider() {
    if (!portfolioSlider || !portfolioPrev || !portfolioNext) return;
    
    const portfolioItems = portfolioSlider.querySelectorAll('.portfolio-item');
    const totalItems = portfolioItems.length;
    let currentIndex = 0;
    
    function updatePortfolioDisplay() {
        const translateX = -currentIndex * (100 / config.portfolioPerView);
        portfolioSlider.style.transform = `translateX(${translateX}%)`;
        
        // Update navigation buttons
        portfolioPrev.style.opacity = currentIndex === 0 ? '0.5' : '1';
        portfolioNext.style.opacity = currentIndex >= totalItems - config.portfolioPerView ? '0.5' : '1';
    }
    
    portfolioPrev.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex--;
            updatePortfolioDisplay();
        }
    });
    
    portfolioNext.addEventListener('click', () => {
        if (currentIndex < totalItems - config.portfolioPerView) {
            currentIndex++;
            updatePortfolioDisplay();
        }
    });
    
    // Initialize display
    updatePortfolioDisplay();
    
    // Add swipe support
    addSwipeSupport(portfolioSlider, 
        () => portfolioPrev.click(),
        () => portfolioNext.click()
    );
}

// Products Slider (6 products)
function initializeProductsSlider() {
    if (!productsSlider || !productsPrev || !productsNext) return;
    
    const productItems = productsSlider.querySelectorAll('.product-card');
    const totalProducts = productItems.length;
    let currentIndex = 0;
    
    function updateProductsDisplay() {
        const translateX = -currentIndex * (100 / config.productsPerView);
        productsSlider.style.transform = `translateX(${translateX}%)`;
        
        // Update navigation buttons visibility and state
        productsPrev.style.opacity = currentIndex === 0 ? '0.5' : '1';
        productsNext.style.opacity = currentIndex >= totalProducts - config.productsPerView ? '0.5' : '1';
        
        productsPrev.disabled = currentIndex === 0;
        productsNext.disabled = currentIndex >= totalProducts - config.productsPerView;
    }
    
    productsPrev.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex--;
            updateProductsDisplay();
        }
    });
    
    productsNext.addEventListener('click', () => {
        if (currentIndex < totalProducts - config.productsPerView) {
            currentIndex++;
            updateProductsDisplay();
        }
    });
    
    // Initialize display
    updateProductsDisplay();
    
    // Add swipe support
    addSwipeSupport(productsSlider,
        () => productsPrev.click(),
        () => productsNext.click()
    );
}

// Videos Slider
function initializeVideosSlider() {
    if (!videosPrev || !videosNext || !videoItems.length) return;
    
    let currentVideoIndex = 0;
    const totalVideos = videoItems.length;
    
    function updateVideosDisplay() {
        videoItems.forEach((item, index) => {
            if (index >= currentVideoIndex && index < currentVideoIndex + config.videosPerView) {
                item.style.display = 'block';
                item.style.animation = 'fadeInUp 0.6s ease';
            } else {
                item.style.display = 'none';
            }
        });
        
        videosPrev.style.opacity = currentVideoIndex === 0 ? '0.5' : '1';
        videosNext.style.opacity = currentVideoIndex >= totalVideos - config.videosPerView ? '0.5' : '1';
    }
    
    videosPrev.addEventListener('click', () => {
        if (currentVideoIndex > 0) {
            currentVideoIndex--;
            updateVideosDisplay();
        }
    });
    
    videosNext.addEventListener('click', () => {
        if (currentVideoIndex < totalVideos - config.videosPerView) {
            currentVideoIndex++;
            updateVideosDisplay();
        }
    });
    
    // Video play functionality
    videoItems.forEach(item => {
        const videoPlaceholder = item.querySelector('.video-placeholder');
        if (videoPlaceholder) {
            videoPlaceholder.addEventListener('click', function() {
                const videoTitle = this.querySelector('span').textContent;
                playVideo(videoTitle);
            });
        }
    });
    
    // Initialize display
    updateVideosDisplay();
}

function playVideo(title) {
    // Create video modal
    const videoModal = document.createElement('div');
    videoModal.className = 'video-modal show';
    videoModal.innerHTML = `
        <div class="video-modal-content">
            <span class="video-close">&times;</span>
            <h3>${title}</h3>
            <div class="video-player">
                <div class="video-placeholder-large">
                    <i class="fas fa-play" style="font-size: 4rem; color: var(--accent-color);"></i>
                    <p>سيتم إضافة الفيديو قريباً</p>
                    <small>شكراً لاهتمامك!</small>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(videoModal);
    
    const closeBtn = videoModal.querySelector('.video-close');
    closeBtn.addEventListener('click', () => {
        document.body.removeChild(videoModal);
    });
    
    videoModal.addEventListener('click', (e) => {
        if (e.target === videoModal) {
            document.body.removeChild(videoModal);
        }
    });
}

// Popup Triggers
function initializePopupTriggers() {
    if (!popupModal) return;
    
    // Scroll trigger (60%)
    window.addEventListener('scroll', throttle(checkScrollTrigger, 100));
    
    // Time trigger (30 seconds)
    setTimeout(() => {
        if (!popupTriggered) {
            showPopup();
        }
    }, config.popupTimeDelay);
}

function checkScrollTrigger() {
    if (popupTriggered) return;
    
    const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
    const scrolled = window.scrollY / scrollHeight;
    
    if (scrolled >= config.popupScrollTrigger) {
        showPopup();
    }
}

function showPopup() {
    if (popupTriggered) return;
    
    popupTriggered = true;
    openModal(popupModal);
    
    // Store popup state in memory (sessionStorage not available in sandbox)
    window.popupShownThisSession = true;
    console.log('Popup shown this session');
}

// Scroll Animations
function initializeScrollAnimations() {
    const animatedElements = document.querySelectorAll(
        '.service-card, .portfolio-item, .product-card, .problem-card, .package-card, .testimonial-card, .stat-card'
    );
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
                entry.target.style.animation = 'fadeInUp 0.8s ease forwards';
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    animatedElements.forEach(el => {
        el.classList.add('scroll-animate');
        observer.observe(el);
    });
}

// Utility Functions
function addSwipeSupport(element, onSwipeLeft, onSwipeRight) {
    let startX = 0;
    let endX = 0;
    
    element.addEventListener('touchstart', (e) => {
        startX = e.touches[0].clientX;
    }, { passive: true });
    
    element.addEventListener('touchend', (e) => {
        endX = e.changedTouches[0].clientX;
        handleSwipe();
    }, { passive: true });
    
    function handleSwipe() {
        const swipeThreshold = 50;
        const diff = startX - endX;
        
        if (Math.abs(diff) > swipeThreshold) {
            if (diff > 0) {
                // Swipe left - next
                onSwipeRight();
            } else {
                // Swipe right - previous
                onSwipeLeft();
            }
        }
    }
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}

// Enhanced Mobile Menu
function initializeMobileMenu() {
    if (!mobileMenuToggle || !nav) return;
    
    mobileMenuToggle.addEventListener('click', function() {
        nav.classList.toggle('active');
        document.body.classList.toggle('menu-open');
        
        const icon = this.querySelector('i');
        if (nav.classList.contains('active')) {
            icon.classList.remove('fa-bars');
            icon.classList.add('fa-times');
            this.setAttribute('aria-expanded', 'true');
        } else {
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
            this.setAttribute('aria-expanded', 'false');
        }
    });
    
    // Close menu when clicking nav link
    const navLinks = nav.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            nav.classList.remove('active');
            document.body.classList.remove('menu-open');
            const icon = mobileMenuToggle.querySelector('i');
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
            mobileMenuToggle.setAttribute('aria-expanded', 'false');
        });
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
        if (!nav.contains(e.target) && !mobileMenuToggle.contains(e.target)) {
            nav.classList.remove('active');
            document.body.classList.remove('menu-open');
            const icon = mobileMenuToggle.querySelector('i');
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
            mobileMenuToggle.setAttribute('aria-expanded', 'false');
        }
    });
}

// New Enhanced Functions

// Modal System
function initializeModals() {
    // Search Modal
    if (searchBtn && searchModal) {
        searchBtn.addEventListener('click', () => openModal(searchModal));
    }
    
    if (searchClose) {
        searchClose.addEventListener('click', () => closeModal(searchModal));
    }
    
    // Catalog Modal
    if (downloadBtn && catalogModal) {
        downloadBtn.addEventListener('click', () => openModal(catalogModal));
    }
    
    if (catalogClose) {
        catalogClose.addEventListener('click', () => closeModal(catalogModal));
    }
    
    // Catalog options
    if (directDownload) {
        directDownload.addEventListener('click', function() {
            // Simulate direct download
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التحضير...';
            setTimeout(() => {
                alert('تم إرسال رابط التحميل على الواتساب!');
                window.open('https://wa.me/201068274662?text=' + encodeURIComponent('أريد تحميل الكتالوج العام'), '_blank');
                closeModal(catalogModal);
            }, 2000);
        });
    }
    
    if (customCatalog) {
        customCatalog.addEventListener('click', function() {
            catalogForm.style.display = 'block';
            this.style.display = 'none';
            directDownload.style.display = 'none';
        });
    }
    
    // Popup Modal
    if (popupClose) {
        popupClose.addEventListener('click', () => closeModal(popupModal));
    }
    
    // Close modals when clicking outside
    [searchModal, catalogModal, popupModal].forEach(modal => {
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    closeModal(modal);
                }
            });
        }
    });
    
    // Close modals with Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            [searchModal, catalogModal, popupModal].forEach(modal => {
                if (modal && modal.classList.contains('show')) {
                    closeModal(modal);
                }
            });
        }
    });
}

function openModal(modal) {
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Focus first input
        const firstInput = modal.querySelector('input');
        if (firstInput) {
            setTimeout(() => firstInput.focus(), 300);
        }
    }
}

function closeModal(modal) {
    if (modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
        
        // Reset form if exists
        const form = modal.querySelector('form');
        if (form) {
            form.reset();
            form.querySelectorAll('.error').forEach(el => el.classList.remove('error'));
        }
        
        // Reset catalog modal state
        if (modal === catalogModal) {
            catalogForm.style.display = 'none';
            directDownload.style.display = 'inline-block';
            customCatalog.style.display = 'inline-block';
        }
    }
}

// Search Functionality
function initializeSearchFunctionality() {
    if (!searchInput || !searchResults) return;
    
    const searchData = [
        { title: 'خدماتنا', content: 'تصميم مواقع، تسويق رقمي، إدارة حسابات', url: '#services' },
        { title: 'الباقات', content: 'باقات تسويقية متنوعة', url: '#packages' },
        { title: 'أعمالنا', content: 'مشاريع سابقة ونجاحات', url: '#portfolio' },
        { title: 'من نحن', content: '15 سنة خبرة في التسويق', url: '#about' },
        { title: 'اتصل بنا', content: 'رقم الهاتف والواتساب', url: '#contact' },
        { title: 'المنتجات الرقمية', content: 'كورسات ودلائل تسويقية', url: '#products' }
    ];
    
    let searchTimeout;
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        const query = this.value.trim();
        
        if (query.length === 0) {
            searchResults.innerHTML = '';
            return;
        }
        
        searchTimeout = setTimeout(() => {
            const results = searchData.filter(item => 
                item.title.includes(query) || item.content.includes(query)
            );
            
            displaySearchResults(results, query);
        }, 300);
    });
}

function displaySearchResults(results, query) {
    if (results.length === 0) {
        searchResults.innerHTML = `
            <div class="no-results">
                <i class="fas fa-search"></i>
                <p>لم يتم العثور على نتائج لـ "${query}"</p>
                <a href="#contact" class="btn btn-primary btn-small">اتصل بنا للمساعدة</a>
            </div>
        `;
        return;
    }
    
    searchResults.innerHTML = results.map(result => `
        <div class="search-result-item" onclick="handleSearchClick('${result.url}')">
            <h4>${result.title}</h4>
            <p>${result.content}</p>
        </div>
    `).join('');
}

function handleSearchClick(url) {
    closeModal(searchModal);
    
    // Smooth scroll to section
    const target = document.querySelector(url);
    if (target) {
        const headerHeight = document.querySelector('.header').offsetHeight;
        const targetPosition = target.offsetTop - headerHeight - 20;
        
        window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
        });
    }
};

// Enhanced Application Initialization
document.addEventListener('DOMContentLoaded', function() {
    initializeHeroSlider();
    initializeTestimonials();
    initializeCountdownTimer();
    initializeCounters();
    initializeFAQ();
    initializeForms();
    initializeSmoothScroll();
    initializeMobileMenu();
    initializeAnimations();
    
    // New Enhanced Features
    initializeModals();
    initializeProblemsSlider();
    initializePortfolioSlider();
    initializeProductsSlider();
    initializeVideosSlider();
    initializePopupTriggers();
    initializeScrollAnimations();
    initializeSearchFunctionality();
    
    // Add loading states
    document.body.classList.add('loaded');
    
    console.log('🚀 سويد للتسويق والإعلان - الموقع جاهز!');
});

// Enhanced Hero Slider Functionality
function initializeHeroSlider() {
    if (!heroSlides.length) return;
    
    // Auto slide every 8 seconds (as requested)
    autoSlideInterval = setInterval(nextSlide, config.heroAutoSlideDelay);
    
    // Button event listeners
    if (prevSlideBtn) {
        prevSlideBtn.addEventListener('click', () => {
            clearInterval(autoSlideInterval);
            prevSlide();
            resetAutoSlide();
        });
    }
    
    if (nextSlideBtn) {
        nextSlideBtn.addEventListener('click', () => {
            clearInterval(autoSlideInterval);
            nextSlide();
            resetAutoSlide();
        });
    }
    
    // Dots event listeners with enhanced feedback
    heroDots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            clearInterval(autoSlideInterval);
            goToSlide(index);
            resetAutoSlide();
        });
        
        dot.addEventListener('mouseenter', () => {
            dot.style.transform = 'scale(1.3)';
        });
        
        dot.addEventListener('mouseleave', () => {
            if (!dot.classList.contains('active')) {
                dot.style.transform = 'scale(1)';
            }
        });
    });
    
    // Enhanced video play functionality
    const videoOverlays = document.querySelectorAll('.video-overlay');
    videoOverlays.forEach(overlay => {
        overlay.addEventListener('click', function() {
            playHeroVideo(this);
        });
    });
    
    // Pause on hover
    const heroSection = document.querySelector('.hero');
    if (heroSection) {
        heroSection.addEventListener('mouseenter', () => {
            clearInterval(autoSlideInterval);
        });
        
        heroSection.addEventListener('mouseleave', () => {
            resetAutoSlide();
        });
    }
    
    // Initialize first slide
    updateSlideIndicators();
}

function resetAutoSlide() {
    clearInterval(autoSlideInterval);
    autoSlideInterval = setInterval(nextSlide, config.heroAutoSlideDelay);
}

function playHeroVideo(overlay) {
    // Enhanced video play with modal-like experience
    const videoModal = document.createElement('div');
    videoModal.className = 'video-modal';
    videoModal.innerHTML = `
        <div class="video-modal-content">
            <span class="video-close">&times;</span>
            <div class="video-container">
                <div class="video-placeholder-large">
                    <i class="fas fa-play" style="font-size: 4rem;"></i>
                    <h3>فيديو تعريفي عن شركة سويد</h3>
                    <p>قصص نجاح حقيقية وشهادات من عملائنا</p>
                    <button class="btn btn-primary" onclick="alert('سيتم إضافة الفيديو قريباً')">مشاهدة الفيديو</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(videoModal);
    videoModal.style.display = 'flex';
    
    const closeBtn = videoModal.querySelector('.video-close');
    closeBtn.addEventListener('click', () => {
        document.body.removeChild(videoModal);
    });
    
    videoModal.addEventListener('click', (e) => {
        if (e.target === videoModal) {
            document.body.removeChild(videoModal);
        }
    });
}

function nextSlide() {
    if (!heroSlides.length) return;
    
    // Enhanced slide transition
    heroSlides[currentSlide].classList.add('exiting');
    heroDots[currentSlide].classList.remove('active');
    
    setTimeout(() => {
        heroSlides[currentSlide].classList.remove('active', 'exiting');
        currentSlide = (currentSlide + 1) % heroSlides.length;
        heroSlides[currentSlide].classList.add('active', 'entering');
        heroDots[currentSlide].classList.add('active');
        updateSlideIndicators();
        
        setTimeout(() => {
            heroSlides[currentSlide].classList.remove('entering');
        }, 100);
    }, 100);
}

function prevSlide() {
    if (!heroSlides.length) return;
    
    // Enhanced slide transition
    heroSlides[currentSlide].classList.add('exiting');
    heroDots[currentSlide].classList.remove('active');
    
    setTimeout(() => {
        heroSlides[currentSlide].classList.remove('active', 'exiting');
        currentSlide = currentSlide === 0 ? heroSlides.length - 1 : currentSlide - 1;
        heroSlides[currentSlide].classList.add('active', 'entering');
        heroDots[currentSlide].classList.add('active');
        updateSlideIndicators();
        
        setTimeout(() => {
            heroSlides[currentSlide].classList.remove('entering');
        }, 100);
    }, 100);
}

function goToSlide(slideIndex) {
    if (!heroSlides.length || slideIndex === currentSlide) return;
    
    heroSlides[currentSlide].classList.add('exiting');
    heroDots[currentSlide].classList.remove('active');
    
    setTimeout(() => {
        heroSlides[currentSlide].classList.remove('active', 'exiting');
        currentSlide = slideIndex;
        heroSlides[currentSlide].classList.add('active', 'entering');
        heroDots[currentSlide].classList.add('active');
        updateSlideIndicators();
        
        setTimeout(() => {
            heroSlides[currentSlide].classList.remove('entering');
        }, 100);
    }, 100);
}

function updateSlideIndicators() {
    heroDots.forEach((dot, index) => {
        dot.style.transform = index === currentSlide ? 'scale(1.2)' : 'scale(1)';
    });
}

// Enhanced Testimonials Functionality
function initializeTestimonials() {
    if (!testimonialCards.length) return;
    
    // Auto rotate testimonials every 7 seconds
    setInterval(nextTestimonial, config.testimonialAutoSlideDelay);
    
    if (prevTestimonialBtn) {
        prevTestimonialBtn.addEventListener('click', prevTestimonial);
    }
    
    if (nextTestimonialBtn) {
        nextTestimonialBtn.addEventListener('click', nextTestimonial);
    }
    
    // Add swipe support for testimonials
    const testimonialsSlider = document.querySelector('.testimonials-slider');
    if (testimonialsSlider) {
        addSwipeSupport(testimonialsSlider, prevTestimonial, nextTestimonial);
    }
}

function nextTestimonial() {
    if (!testimonialCards.length) return;
    
    testimonialCards[currentTestimonial].classList.remove('active');
    testimonialCards[currentTestimonial].style.opacity = '0';
    
    setTimeout(() => {
        currentTestimonial = (currentTestimonial + 1) % testimonialCards.length;
        testimonialCards[currentTestimonial].classList.add('active');
        testimonialCards[currentTestimonial].style.opacity = '1';
    }, 300);
}

function prevTestimonial() {
    if (!testimonialCards.length) return;
    
    testimonialCards[currentTestimonial].classList.remove('active');
    testimonialCards[currentTestimonial].style.opacity = '0';
    
    setTimeout(() => {
        currentTestimonial = currentTestimonial === 0 ? testimonialCards.length - 1 : currentTestimonial - 1;
        testimonialCards[currentTestimonial].classList.add('active');
        testimonialCards[currentTestimonial].style.opacity = '1';
    }, 300);
}

// Enhanced Countdown Timer
function initializeCountdownTimer() {
    const timerElements = {
        days: document.getElementById('days'),
        hours: document.getElementById('hours'),
        minutes: document.getElementById('minutes')
    };
    
    // Set target date (30 days from now)
    const targetDate = new Date();
    targetDate.setDate(targetDate.getDate() + 30);
    targetDate.setHours(23, 59, 59, 999);
    
    function updateTimer() {
        const now = new Date().getTime();
        const distance = targetDate.getTime() - now;
        
        if (distance < 0) {
            // Timer expired - show renewal message
            if (timerElements.days) timerElements.days.textContent = '00';
            if (timerElements.hours) timerElements.hours.textContent = '00';
            if (timerElements.minutes) timerElements.minutes.textContent = '00';
            
            const countdownTimer = document.querySelector('.countdown-timer');
            if (countdownTimer) {
                const renewalMsg = document.createElement('div');
                renewalMsg.className = 'renewal-message';
                renewalMsg.innerHTML = `
                    <p>انتهى العرض! اتصل بنا للحصول على عروض جديدة</p>
                    <a href="tel:01068274662" class="btn btn-primary">اتصل الآن</a>
                `;
                countdownTimer.appendChild(renewalMsg);
            }
            return;
        }
        
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        
        // Animate number changes
        if (timerElements.days) animateNumber(timerElements.days, days.toString().padStart(2, '0'));
        if (timerElements.hours) animateNumber(timerElements.hours, hours.toString().padStart(2, '0'));
        if (timerElements.minutes) animateNumber(timerElements.minutes, minutes.toString().padStart(2, '0'));
        
        // Add urgency styling when less than 24 hours
        if (distance < 24 * 60 * 60 * 1000) {
            const countdownTimer = document.querySelector('.countdown-timer');
            if (countdownTimer && !countdownTimer.classList.contains('urgent')) {
                countdownTimer.classList.add('urgent');
                countdownTimer.style.animation = 'pulse-urgent 2s infinite';
            }
        }
    }
    
    function animateNumber(element, newValue) {
        if (element.textContent !== newValue) {
            element.style.transform = 'scale(1.2)';
            element.textContent = newValue;
            setTimeout(() => {
                element.style.transform = 'scale(1)';
            }, 200);
        }
    }
    
    updateTimer();
    setInterval(updateTimer, 60000); // Update every minute
    
    // Update seconds for more dynamic feel (first 10 seconds)
    let secondsCounter = 10;
    const secondsInterval = setInterval(() => {
        if (secondsCounter <= 0) {
            clearInterval(secondsInterval);
            return;
        }
        secondsCounter--;
        updateTimer();
    }, 1000);
}

// Enhanced Animated Counters
function initializeCounters() {
    const statNumbers = document.querySelectorAll('.stat-number');
    let animated = false;
    
    function animateCounters() {
        if (animated) return;
        
        statNumbers.forEach((stat, index) => {
            const target = parseInt(stat.getAttribute('data-target'));
            const increment = target / 80; // Smoother animation
            let current = 0;
            
            // Stagger animation start
            setTimeout(() => {
                const timer = setInterval(() => {
                    current += increment;
                    if (current >= target) {
                        current = target;
                        clearInterval(timer);
                        
                        // Add completion effect
                        stat.style.transform = 'scale(1.1)';
                        setTimeout(() => {
                            stat.style.transform = 'scale(1)';
                        }, 200);
                    }
                    
                    let displayValue = Math.floor(current);
                    if (target >= 100) {
                        stat.textContent = displayValue + '+';
                    } else {
                        stat.textContent = displayValue + (target === 98 ? '%' : '');
                    }
                }, 30);
            }, index * 200); // Stagger by 200ms
        });
        
        animated = true;
    }
    
    // Trigger animation when stats section comes into view
    const statsSection = document.querySelector('.stats');
    if (statsSection) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounters();
                    // Add section animation
                    statsSection.style.animation = 'fadeInUp 1s ease';
                }
            });
        }, { threshold: 0.3 });
        
        observer.observe(statsSection);
    }
}

// FAQ Accordion
function initializeFAQ() {
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', () => {
            const isActive = item.classList.contains('active');
            
            // Close all other FAQ items
            faqItems.forEach(otherItem => {
                if (otherItem !== item) {
                    otherItem.classList.remove('active');
                }
            });
            
            // Toggle current item
            if (isActive) {
                item.classList.remove('active');
            } else {
                item.classList.add('active');
            }
        });
    });
}

// Enhanced Form Handling
function initializeForms() {
    // Help request form
    if (helpForm) {
        helpForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleFormSubmission(this, 'help-request');
        });
    }
    
    // Catalog form
    if (catalogForm) {
        catalogForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleFormSubmission(this, 'catalog-request');
        });
    }
    
    // Popup form
    if (popupForm) {
        popupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleFormSubmission(this, 'popup-consultation');
            closeModal(popupModal);
        });
    }
    
    // Add real-time validation
    const allInputs = document.querySelectorAll('input, select, textarea');
    allInputs.forEach(input => {
        input.addEventListener('blur', validateField);
        input.addEventListener('input', clearFieldError);
    });
}

function handleFormSubmission(form, type) {
    const formData = new FormData(form);
    const name = form.querySelector('input[type="text"]')?.value;
    const phone = form.querySelector('input[type="tel"]')?.value;
    const service = form.querySelector('select')?.value;
    
    // Enhanced validation
    const errors = validateForm(form);
    if (errors.length > 0) {
        showFormErrors(errors);
        return;
    }
    
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    
    // Enhanced loading state
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الإرسال...';
    submitBtn.disabled = true;
    form.classList.add('loading');
    
    // Simulate API call
    setTimeout(() => {
        form.classList.remove('loading');
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
        
        // Show success message based on type
        const messages = {
            'help-request': 'تم إرسال طلبك بنجاح! سنتواصل معك خلال 24 ساعة.',
            'catalog-request': 'تم طلب الكتالوج بنجاح! سنرسله على الواتساب خلال دقائق.',
            'popup-consultation': 'تم حجز الاستشارة المجانية! سنتصل بك قريباً.'
        };
        
        showSuccessMessage(messages[type] || 'تم الإرسال بنجاح!');
        form.reset();
        
        // Track conversion (analytics could be added here)
        console.log(`Form submission: ${type}`, { name, phone, service });
        
    }, 2000);
}

function validateForm(form) {
    const errors = [];
    const requiredFields = form.querySelectorAll('[required]');
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            errors.push(`${field.getAttribute('placeholder')} مطلوب`);
            field.classList.add('error');
        }
        
        // Validate phone number
        if (field.type === 'tel' && field.value) {
            const phoneRegex = /^[0-9+\-\s()]+$/;
            if (!phoneRegex.test(field.value) || field.value.length < 10) {
                errors.push('يرجى إدخال رقم هاتف صحيح');
                field.classList.add('error');
            }
        }
    });
    
    return errors;
}

function validateField(e) {
    const field = e.target;
    field.classList.remove('error');
    
    if (field.hasAttribute('required') && !field.value.trim()) {
        field.classList.add('error');
    }
    
    if (field.type === 'tel' && field.value) {
        const phoneRegex = /^[0-9+\-\s()]+$/;
        if (!phoneRegex.test(field.value) || field.value.length < 10) {
            field.classList.add('error');
        }
    }
}

function clearFieldError(e) {
    e.target.classList.remove('error');
}

function showFormErrors(errors) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'form-errors';
    errorDiv.innerHTML = `
        <div class="error-message">
            <i class="fas fa-exclamation-triangle"></i>
            <ul>${errors.map(error => `<li>${error}</li>`).join('')}</ul>
        </div>
    `;
    
    // Remove any existing error messages
    const existingErrors = document.querySelectorAll('.form-errors');
    existingErrors.forEach(el => el.remove());
    
    document.body.appendChild(errorDiv);
    
    setTimeout(() => {
        errorDiv.remove();
    }, 5000);
}

function showSuccessMessage(message) {
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.innerHTML = `
        <div class="success-content">
            <i class="fas fa-check-circle"></i>
            <p>${message}</p>
        </div>
    `;
    
    document.body.appendChild(successDiv);
    
    setTimeout(() => {
        successDiv.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        successDiv.classList.remove('show');
        setTimeout(() => {
            if (successDiv.parentNode) {
                successDiv.remove();
            }
        }, 300);
    }, 4000);
}
    
    // Enhanced product purchase buttons
    const productButtons = document.querySelectorAll('.btn-product');
    productButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const productCard = this.closest('.product-card');
            const productName = productCard.querySelector('h3').textContent;
            const productPrice = productCard.querySelector('.current-price').textContent;
            
            // Add visual feedback
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الإضافة...';
            this.disabled = true;
            
            setTimeout(() => {
                if (productPrice.includes('مجان')) {
                    showSuccessMessage(`تم حجز ${productName} بنجاح! سنتواصل معك لتحديد موعد الاستشارة.`);
                    // Could redirect to consultation booking
                    setTimeout(() => {
                        window.open('https://wa.me/201068274662?text=' + encodeURIComponent(`أريد حجز ${productName}`), '_blank');
                    }, 2000);
                } else {
                    showSuccessMessage(`تم إضافة ${productName} إلى السلة.`);
                    // Could integrate with payment system
                    console.log('Product added to cart:', { name: productName, price: productPrice });
                }
                
                this.textContent = 'تم الإضافة ✓';
                this.style.background = '#28a745';
                
                setTimeout(() => {
                    this.textContent = productPrice.includes('مجان') ? 'احجز الآن' : 'اشتري الآن';
                    this.style.background = '';
                    this.disabled = false;
                }, 3000);
            }, 1500);
        });
    });
    
    // Enhanced package selection buttons
    const packageButtons = document.querySelectorAll('.btn-package');
    packageButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const packageCard = this.closest('.package-card');
            const packageName = packageCard.querySelector('h3').textContent;
            const packagePrice = packageCard.querySelector('.current-price').textContent;
            
            // Add visual feedback
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التحديد...';
            this.disabled = true;
            
            // Highlight selected package
            document.querySelectorAll('.package-card').forEach(card => {
                card.classList.remove('selected');
            });
            packageCard.classList.add('selected');
            
            setTimeout(() => {
                showSuccessMessage(`تم اختيار ${packageName}! سنتواصل معك خلال ساعة لمناقشة التفاصيل.`);
                
                // Open WhatsApp with package details
                const message = `أريد الاستفسار عن ${packageName} بسعر ${packagePrice}`;
                setTimeout(() => {
                    window.open('https://wa.me/201068274662?text=' + encodeURIComponent(message), '_blank');
                }, 2000);
                
                this.innerHTML = '<i class="fas fa-check"></i> تم الاختيار';
                this.style.background = '#28a745';
                
                setTimeout(() => {
                    this.textContent = 'اختر الباقة';
                    this.style.background = '';
                    this.disabled = false;
                    packageCard.classList.remove('selected');
                }, 5000);
            }, 1500);
        });
    });
    
    // Enhanced CTA buttons
    const ctaButtons = document.querySelectorAll('.btn-cta-primary, .btn-cta-secondary');
    ctaButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Add click animation
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
            
            if (this.textContent.includes('استشارة')) {
                // Show consultation booking modal or redirect to WhatsApp
                const message = 'أريد حجز استشارة مجانية';
                window.open('https://wa.me/201068274662?text=' + encodeURIComponent(message), '_blank');
            } else if (this.textContent.includes('اتصل')) {
                // Add confirmation before calling
                if (confirm('هل تريد الاتصال بنا الآن؟')) {
                    window.open('tel:01068274662', '_self');
                }
            }
        });
    });
    
    // WhatsApp buttons
    const whatsappButtons = document.querySelectorAll('.btn-cta-whatsapp, .whatsapp-float a');
    whatsappButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            const message = 'مرحباً، أريد الاستفسار عن خدماتكم';
            window.open('https://wa.me/201068274662?text=' + encodeURIComponent(message), '_blank');
            
            // Track WhatsApp clicks
            console.log('WhatsApp button clicked');
        });
    });
}

// Smooth Scrolling
function initializeSmoothScroll() {
    const navLinks = document.querySelectorAll('a[href^="#"]');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = targetSection.offsetTop - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // Update active nav link
                navLinks.forEach(navLink => {
                    navLink.classList.remove('active');
                });
                this.classList.add('active');
                
                // Close mobile menu if open
                nav.classList.remove('active');
            }
        });
    });
}

// Mobile Menu
function initializeMobileMenu() {
    if (mobileMenuToggle && nav) {
        mobileMenuToggle.addEventListener('click', function() {
            nav.classList.toggle('active');
            const icon = this.querySelector('i');
            
            if (nav.classList.contains('active')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
    }
}

// Scroll Animations
function initializeAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Animate cards and sections
    const animatedElements = document.querySelectorAll(
        '.problem-card, .advantage-card, .service-card, .portfolio-item, .package-card, .product-card, .article-card, .timeline-item'
    );
    
    animatedElements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = `all 0.6s ease ${index * 0.1}s`;
        observer.observe(el);
    });
}

// Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Handle window resize
window.addEventListener('resize', debounce(() => {
    // Recalculate any size-dependent features
    console.log('Window resized');
}, 250));

// Page visibility change
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        // Pause animations when page is not visible
        document.body.style.animationPlayState = 'paused';
    } else {
        // Resume animations when page becomes visible
        document.body.style.animationPlayState = 'running';
    }
});

// Error handling
window.addEventListener('error', (e) => {
    console.error('JavaScript error:', e.error);
});

// Touch gestures for mobile
let touchStartX = 0;
let touchEndX = 0;

function handleGesture() {
    const swipeThreshold = 50;
    const swipeDistance = touchEndX - touchStartX;
    
    if (Math.abs(swipeDistance) > swipeThreshold) {
        if (swipeDistance > 0) {
            // Swipe right - previous slide
            prevSlide();
        } else {
            // Swipe left - next slide
            nextSlide();
        }
    }
}

// Add touch listeners to hero section
const heroSection = document.querySelector('.hero');
if (heroSection) {
    heroSection.addEventListener('touchstart', e => {
        touchStartX = e.changedTouches[0].screenX;
    });
    
    heroSection.addEventListener('touchend', e => {
        touchEndX = e.changedTouches[0].screenX;
        handleGesture();
    });
}

// Performance Monitoring
function initializePerformanceMonitoring() {
    // Page load time
    window.addEventListener('load', () => {
        const loadTime = performance.now();
        console.log(`⚡ Page loaded in ${Math.round(loadTime)}ms`);
        
        // Log any slow-loading elements
        if (loadTime > 3000) {
            console.warn('⚠️ Page load time is slow. Consider optimizing images and scripts.');
        }
    });
    
    // Monitor scroll performance
    let scrollTimeout;
    window.addEventListener('scroll', () => {
        if (scrollTimeout) return;
        
        scrollTimeout = setTimeout(() => {
            scrollTimeout = null;
            scrollPosition = window.scrollY;
        }, 16); // ~60fps
    });
}

// Error Handling
function initializeErrorHandling() {
    window.addEventListener('error', (e) => {
        console.error('🚨 JavaScript Error:', e.error);
        
        // Could send to analytics service
        // trackError(e.error);
    });
    
    window.addEventListener('unhandledrejection', (e) => {
        console.error('🚨 Unhandled Promise Rejection:', e.reason);
    });
}

// Initialize performance monitoring
initializePerformanceMonitoring();
initializeErrorHandling();

// Enhanced Console Messages
console.log('%c🎉 مرحباً بك في موقع شركة سويد للتسويق والإعلان!', 'color: #ed2062; font-size: 18px; font-weight: bold;');
console.log('%c📞 للتواصل المباشر: 01068274662', 'color: #261b3e; font-size: 14px; font-weight: 600;');
console.log('%c✉️ البريد الإلكتروني: info@sweid.com', 'color: #261b3e; font-size: 14px;');
console.log('%c💬 واتساب: https://wa.me/201068274662', 'color: #25D366; font-size: 14px; font-weight: 600;');
console.log('%c🚀 الموقع جاهز مع جميع الميزات المحسنة!', 'color: #261b3e; font-size: 14px; background: #f0f0f0; padding: 5px 10px; border-radius: 5px;');

// Feature Detection
if ('serviceWorker' in navigator) {
    console.log('✅ Service Worker supported');
}
if ('IntersectionObserver' in window) {
    console.log('✅ Intersection Observer supported');
}
if ('requestAnimationFrame' in window) {
    console.log('✅ Animation Frame supported');
